#include "lista.h"

Lista::Lista()
{
    primero = NULL;
    ultimo = NULL;
}

void LstAvion::addColaDoble(Avion *nuevoAvion)
{
    Nodo *nuevo = new Nodo();
    if(primero ==NULL)
    {

    }
    else
    {

    }
}
