#include "nodo.h"

Nodo::Nodo()
{
    siguiente = NULL;
    anterior = NULL;

}
